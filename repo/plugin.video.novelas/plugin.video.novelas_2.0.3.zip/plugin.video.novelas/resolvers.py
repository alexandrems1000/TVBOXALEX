# -*- coding: utf-8 -*-
from BeautifulSoup import BeautifulSoup
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP
from bs4 import BeautifulSoup as bs4Soap
from tools import *
from datetime import date
import mechanize, cookielib, base64
import jsunpack

def obtem_videomail(url):
        ow = open('vidomail.txt','w')
        ow.write(url)
        ow.close()
	import mechanize
	import cookielib
	
	br = mechanize.Browser()
	
	cj = cookielib.LWPCookieJar()
	br.set_cookiejar(cj)
	br.set_handle_equiv(True)
	br.set_handle_gzip(True)
	br.set_handle_redirect(True)
	br.set_handle_referer(True)
	br.set_handle_robots(False)
	br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(), max_time=1)
	br.addheaders = [('User-agent', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.1) Gecko/2008071615 Fedora/3.0.1-1.fc9 Firefox/3.0.1')]
	agent = "Mozilla%2F5.0%20(Windows%20NT%206.3%3B%20WOW64)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F38.0.2125.111%20Safari%2F537.36"
	#try:
        import json
        codigo_fonte = br.open(url).read()
        fjson = json.loads(br.open(re.findall(r'"metadataUrl":"(.*?)"',codigo_fonte)[0]).read())
        vkey = cj._cookies[".my.mail.ru"]["/"]["video_key"].value
        for key in fjson['videos']:
            url_video = key['url']
        return [url_video+"|referer="+url_video+"&User-agent="+agent+"&Cookie=video_key="+vkey,"-"]
	#except:
	#	return ["-","-"]

def obtem_vidig2(url):
    import jsbeautifier.unpackers.packer as packer
    soup = BeautifulSoup(abrir_url(url))
    codigo_fonte = packer.unpack(soup('script')[6].text)
    #ow = open(r'G:\\html_list\\script4.html','w')
    #ow.write(str(soup('script')[6]))
    #ow.close()#"(http://.*?/v.flv)"
    try:
	    url_video = re.findall(r"'(http://.*?/v.mp4)\\'",codigo_fonte)[0]
	    return [url_video+'|User-Agent=Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.104 Safari/537.36',"-"]
    except:
	    pass
	
    try:
	    url_video = re.findall(r'"(http://.*?/v.flv)"',codigo_fonte)[0]
	    return [url_video+'|User-Agent=Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.104 Safari/537.36',"-"]
    except:
	    return ["-","-"]

def obtem_vidig(url):
	opener = urllib2.build_opener()
	opener.addheaders.append(('User-Agent','Mozilla/5.0 (Linux; U; Android 2.2; en-gb; GT-P1000 Build/FROYO) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1'))
	##opener.addheaders.append(('Referer', 'http://50.7.74.98:88/stalker_portal/c/'))
	codigo_fonte = opener.open(url).read()
	try:
		url_video = re.findall(r'"(.*?\.m3u8\?embed=1)"',codigo_fonte)[0]
		return [url_video+'|User-Agent=Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.104 Safari/537.36',"-"]
	except:
		return ["-","-"]

##def obtem_url_dropvideo(url):
##	codigo_fonte = abrir_url(url)
##        if not 'dropvideo.com/embed/' in url:
##                id_video = re.findall(r'<iframe src="http://www.dropvideo.com/embed/(.*?)/"',codigo_fonte)[0]
##                codigo_fonte = abrir_url('http://www.dropvideo.com/embed/%s/' % id_video)
##                url_video = re.findall(r'var vurl2 = "(.*?)";',codigo_fonte)[0]
##                url_legendas =	re.compile('var vsubtitle = "(.*?)";').findall(codigo_fonte)[0]
##        else:
##                codigo_fonte = abrir_url(url)
##                url_video = re.findall(r'var vurl2 = "(.*?)";',codigo_fonte)[0]
##                url_legendas =	re.compile('var vsubtitle = "(.*?)";').findall(codigo_fonte)[0]
##	#except:
##	#	url_video = '-'
##	#	url_legendas = '-'
##	return [url_video+'|User-Agent=Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.104 Safari/537.36',url_legendas]


def obtem_url_dropvideo(url):
        import mechanize
	import cookielib
	
	br = mechanize.Browser()
	
	cj = cookielib.LWPCookieJar()
	br.set_cookiejar(cj)
	br.set_handle_equiv(True)
	br.set_handle_gzip(True)
	br.set_handle_redirect(True)
	br.set_handle_referer(True)
	br.set_handle_robots(False)
	br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(), max_time=1)
	br.addheaders = [('User-agent', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.1) Gecko/2008071615 Fedora/3.0.1-1.fc9 Firefox/3.0.1')]
	agent = "Mozilla%2F5.0%20(Windows%20NT%206.3%3B%20WOW64)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F38.0.2125.111%20Safari%2F537.36"
	codigo_fonte = br.open(url).read()
	try:
            soup = bs4Soap(codigo_fonte)
            lista = soup.findAll('script')
            js = str(lista[9]).replace('<script>',"").replace('</script>',"")
            sUnpacked = jsunpack.unpack(js)
            #print sUnpacked
            url_video = re.findall(r'var vurl2="(.*?)";', sUnpacked)
            url_video = str(url_video).replace("['","").replace("']","")
            return [url_video,"-"]
	except:
		return ["-","-"]


def obtem_cloudzilla(url):
	codigo_fonte = abrir_url(url)
	
	try:
		url_video = re.findall(r'vurl.=."(.*?)";',codigo_fonte)[0]
		return [url_video,"-"]
	except:
		return ["-","-"]
