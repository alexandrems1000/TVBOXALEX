plugin.video.cook
================

Kodi Addon for The Cooking Channel Video website

Version 1.0.3 change to improve img res
Version 1.0.2 Added metadata,subtitles, views
Version 1.0.1 initial release

